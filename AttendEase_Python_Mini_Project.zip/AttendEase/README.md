# AttendEase — Student Attendance Management System

A Python mini-project built with Streamlit and Pandas. It is designed as a quick, presentable classroom demo.

## Features
- Dashboard with registered students, present/absent counts, and attendance rate
- Add and remove students
- Mark attendance as Present, Absent, or Late
- Save attendance by date and update it without creating duplicate date entries
- Filter attendance records and download them as CSV
- Calculate each student's attendance percentage
- Local CSV storage in the `data/` folder

## Requirements
- Python 3.10 or newer
- Internet connection for the first installation of packages (not required to run after installation)

## Run on a laptop / PC
1. Extract the ZIP file.
2. Open a terminal or Command Prompt in the project folder.
3. Install dependencies:
   ```bash
   python -m pip install -r requirements.txt
   ```
4. Start the app:
   ```bash
   streamlit run app.py
   ```
5. The app opens in your browser. If it does not, open the local URL printed in the terminal (usually `http://localhost:8501`).

## Demo data
The app creates sample students and today's sample attendance automatically the first time it runs, so the dashboard is not empty. Remove or replace the sample records before using it for real class attendance.

## Project explanation for viva
**Problem:** Paper-based attendance takes time and makes it difficult to summarize attendance records.

**Solution:** AttendEase is a web-based attendance management demo built in Python. It lets a user register students, mark daily attendance, filter records, export CSV data, and view attendance percentages.

**Technology used:**
- Python: application logic
- Streamlit: user interface
- Pandas: tabular data processing
- CSV: local data storage

**Limitations:** This is a local demo, not a multi-user production system. It has no login/role permissions, and CSV files are not suitable for concurrent multi-user use. A future version could use SQLite, authentication, and a deployed server.
