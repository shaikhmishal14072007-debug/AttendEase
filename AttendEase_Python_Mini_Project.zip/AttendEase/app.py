import streamlit as st
import pandas as pd
from pathlib import Path
from datetime import date, datetime

st.set_page_config(
    page_title="AttendEase | Attendance Manager",
    page_icon="📋",
    layout="wide",
    initial_sidebar_state="expanded",
)

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
STUDENTS_FILE = DATA_DIR / "students.csv"
ATTENDANCE_FILE = DATA_DIR / "attendance.csv"

STUDENT_COLUMNS = ["student_id", "name", "department", "semester"]
ATTENDANCE_COLUMNS = ["student_id", "name", "attendance_date", "status", "marked_at"]

def load_csv(path, columns):
    if path.exists():
        try:
            df = pd.read_csv(path, dtype={"student_id": str})
            for col in columns:
                if col not in df.columns:
                    df[col] = ""
            return df[columns]
        except Exception:
            st.error(f"Could not read {path.name}. Please check the file.")
    return pd.DataFrame(columns=columns)

def save_csv(df, path):
    df.to_csv(path, index=False)

def load_students():
    return load_csv(STUDENTS_FILE, STUDENT_COLUMNS)

def load_attendance():
    return load_csv(ATTENDANCE_FILE, ATTENDANCE_COLUMNS)

def seed_demo_data():
    students = load_students()
    if students.empty:
        students = pd.DataFrame([
            ["STU001", "Aarav Patil", "Computer Engineering", "Second Year"],
            ["STU002", "Sara Khan", "Computer Engineering", "Second Year"],
            ["STU003", "Rohan Sharma", "Information Technology", "Second Year"],
            ["STU004", "Aisha Shaikh", "Computer Engineering", "Second Year"],
            ["STU005", "Neha More", "Artificial Intelligence", "Second Year"],
        ], columns=STUDENT_COLUMNS)
        save_csv(students, STUDENTS_FILE)
    attendance = load_attendance()
    if attendance.empty:
        demo_date = date.today().isoformat()
        demo_rows = [
            ["STU001", "Aarav Patil", demo_date, "Present", datetime.now().strftime("%H:%M:%S")],
            ["STU002", "Sara Khan", demo_date, "Present", datetime.now().strftime("%H:%M:%S")],
            ["STU003", "Rohan Sharma", demo_date, "Absent", datetime.now().strftime("%H:%M:%S")],
            ["STU004", "Aisha Shaikh", demo_date, "Present", datetime.now().strftime("%H:%M:%S")],
            ["STU005", "Neha More", demo_date, "Late", datetime.now().strftime("%H:%M:%S")],
        ]
        save_csv(pd.DataFrame(demo_rows, columns=ATTENDANCE_COLUMNS), ATTENDANCE_FILE)

seed_demo_data()
students = load_students()
attendance = load_attendance()

st.markdown("""
<style>
    .main .block-container {padding-top: 1.6rem; padding-bottom: 2rem;}
    [data-testid="stMetric"] {background: #f4f7fb; border: 1px solid #e1e8f0; padding: 14px 16px; border-radius: 12px;}
    .hero {padding: 20px 24px; border-radius: 16px; background: linear-gradient(115deg,#12304a,#176b70); color: white; margin-bottom: 18px;}
    .hero h1 {margin: 0; font-size: 2rem;}
    .hero p {margin: 6px 0 0 0; opacity: .9;}
</style>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("## 📋 AttendEase")
    st.caption("Student Attendance Management")
    page = st.radio("Navigate", ["Dashboard", "Mark Attendance", "Student Management", "Attendance Records"])
    st.divider()
    st.caption("Mini Project • Python + Streamlit + Pandas")
    st.caption("Data is stored locally in CSV files.")

st.markdown("""
<div class="hero">
  <h1>AttendEase</h1>
  <p>A simple, reliable and user-friendly student attendance management system.</p>
</div>
""", unsafe_allow_html=True)

if page == "Dashboard":
    students = load_students()
    attendance = load_attendance()
    today = date.today().isoformat()
    today_records = attendance[attendance["attendance_date"].astype(str) == today]
    present_count = int((today_records["status"] == "Present").sum())
    absent_count = int((today_records["status"] == "Absent").sum())
    late_count = int((today_records["status"] == "Late").sum())
    total_students = len(students)
    marked_count = len(today_records)
    attendance_rate = (present_count / marked_count * 100) if marked_count else 0

    st.subheader("Overview")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Registered Students", total_students)
    c2.metric("Present Today", present_count)
    c3.metric("Absent Today", absent_count)
    c4.metric("Attendance Rate", f"{attendance_rate:.1f}%")

    left, right = st.columns([1.15, 1])
    with left:
        st.markdown("### Today's attendance")
        if today_records.empty:
            st.info("No attendance has been marked today. Open **Mark Attendance** to begin.")
        else:
            summary = today_records["status"].value_counts().reindex(["Present", "Absent", "Late"], fill_value=0)
            chart_df = pd.DataFrame({"Status": summary.index, "Students": summary.values}).set_index("Status")
            st.bar_chart(chart_df)
            st.dataframe(today_records[["student_id", "name", "status"]], use_container_width=True, hide_index=True)
    with right:
        st.markdown("### Project highlights")
        st.markdown("""
        - Add and manage student details
        - Mark Present, Absent or Late
        - Prevent duplicate attendance for the same student and date
        - View attendance records by date
        - Calculate attendance percentage
        - Download records as CSV
        """)
        st.info("Demo data is included so the dashboard looks populated on first launch.")

elif page == "Mark Attendance":
    st.subheader("Mark attendance")
    if students.empty:
        st.warning("Add students first in Student Management.")
    else:
        selected_date = st.date_input("Attendance date", value=date.today())
        date_str = selected_date.isoformat()
        existing = load_attendance()
        existing_day = existing[existing["attendance_date"].astype(str) == date_str]
        st.caption(f"Date selected: {selected_date.strftime('%d %B %Y')}")
        form_df = students[["student_id", "name", "department"]].copy()
        status_map = {}
        for _, student in form_df.iterrows():
            old = existing_day[existing_day["student_id"].astype(str) == str(student["student_id"])]
            default_status = old.iloc[0]["status"] if not old.empty else "Present"
            key = f"status_{student['student_id']}_{date_str}"
            status_map[str(student["student_id"])] = st.selectbox(
                f"{student['name']} ({student['student_id']})",
                ["Present", "Absent", "Late"],
                index=["Present", "Absent", "Late"].index(default_status) if default_status in ["Present", "Absent", "Late"] else 0,
                key=key,
            )
        if st.button("💾 Save Attendance", type="primary", use_container_width=True):
            current = load_attendance()
            current = current[current["attendance_date"].astype(str) != date_str]
            timestamp = datetime.now().strftime("%H:%M:%S")
            new_rows = []
            student_lookup = students.set_index(students["student_id"].astype(str))
            for sid, status in status_map.items():
                row = students[students["student_id"].astype(str) == sid].iloc[0]
                new_rows.append([sid, row["name"], date_str, status, timestamp])
            updated = pd.concat([current, pd.DataFrame(new_rows, columns=ATTENDANCE_COLUMNS)], ignore_index=True)
            save_csv(updated, ATTENDANCE_FILE)
            st.success(f"Attendance saved for {len(new_rows)} students on {date_str}.")
            st.rerun()

elif page == "Student Management":
    st.subheader("Student management")
    with st.expander("➕ Add a new student", expanded=True):
        with st.form("add_student_form", clear_on_submit=True):
            col1, col2 = st.columns(2)
            with col1:
                student_id = st.text_input("Student ID", placeholder="e.g. STU006")
                name = st.text_input("Full name", placeholder="Enter student's name")
            with col2:
                department = st.selectbox("Department", ["Computer Engineering", "Information Technology", "Artificial Intelligence", "Electronics", "Other"])
                semester = st.selectbox("Year / Semester", ["First Year", "Second Year", "Third Year", "Final Year"])
            submitted = st.form_submit_button("Add Student", type="primary")
            if submitted:
                current = load_students()
                sid = student_id.strip().upper()
                clean_name = name.strip()
                if not sid or not clean_name:
                    st.error("Student ID and full name are required.")
                elif (current["student_id"].astype(str).str.upper() == sid).any():
                    st.error("This Student ID already exists. Use a unique ID.")
                else:
                    new_student = pd.DataFrame([[sid, clean_name, department, semester]], columns=STUDENT_COLUMNS)
                    save_csv(pd.concat([current, new_student], ignore_index=True), STUDENTS_FILE)
                    st.success(f"Added {clean_name} successfully.")
                    st.rerun()

    st.markdown("### Registered students")
    current_students = load_students()
    st.dataframe(current_students, use_container_width=True, hide_index=True)
    if not current_students.empty:
        with st.expander("🗑️ Remove a student"):
            remove_id = st.selectbox("Select Student ID", current_students["student_id"].astype(str).tolist())
            if st.button("Remove selected student"):
                remaining = current_students[current_students["student_id"].astype(str) != remove_id]
                save_csv(remaining, STUDENTS_FILE)
                current_attendance = load_attendance()
                current_attendance = current_attendance[current_attendance["student_id"].astype(str) != remove_id]
                save_csv(current_attendance, ATTENDANCE_FILE)
                st.success("Student and their attendance history removed.")
                st.rerun()

elif page == "Attendance Records":
    st.subheader("Attendance records")
    records = load_attendance()
    if records.empty:
        st.info("No records available yet.")
    else:
        col1, col2 = st.columns(2)
        with col1:
            all_dates = sorted(records["attendance_date"].astype(str).unique(), reverse=True)
            chosen_date = st.selectbox("Filter by date", ["All dates"] + all_dates)
        with col2:
            status_filter = st.selectbox("Filter by status", ["All statuses", "Present", "Absent", "Late"])
        filtered = records.copy()
        if chosen_date != "All dates":
            filtered = filtered[filtered["attendance_date"].astype(str) == chosen_date]
        if status_filter != "All statuses":
            filtered = filtered[filtered["status"] == status_filter]
        st.caption(f"{len(filtered)} record(s) shown")
        st.dataframe(filtered, use_container_width=True, hide_index=True)
        csv_bytes = filtered.to_csv(index=False).encode("utf-8")
        st.download_button("⬇️ Download filtered records (CSV)", data=csv_bytes, file_name="attendance_records.csv", mime="text/csv")

    st.markdown("### Student attendance percentage")
    students = load_students()
    records = load_attendance()
    if not students.empty:
        if records.empty:
            st.info("Attendance percentage will appear after records are saved.")
        else:
            summary_rows = []
            for _, student in students.iterrows():
                student_records = records[records["student_id"].astype(str) == str(student["student_id"])]
                total = len(student_records)
                present = int((student_records["status"] == "Present").sum())
                percentage = present / total * 100 if total else 0
                summary_rows.append([student["student_id"], student["name"], total, present, f"{percentage:.1f}%"])
            summary = pd.DataFrame(summary_rows, columns=["Student ID", "Name", "Days Marked", "Present Days", "Attendance %"])
            st.dataframe(summary, use_container_width=True, hide_index=True)

st.divider()
st.caption("AttendEase • Educational mini-project demo. Replace sample records with your actual class data before real use.")
